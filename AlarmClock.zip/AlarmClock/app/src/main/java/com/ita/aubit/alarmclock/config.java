package com.ita.aubit.alarmclock;

public class config {
    public static String CHANNEL_ID="1001";
}
